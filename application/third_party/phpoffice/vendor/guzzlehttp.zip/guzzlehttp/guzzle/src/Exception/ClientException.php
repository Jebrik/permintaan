<?php

namespace PixelCaffeine\Dependencies\GuzzleHttp\Exception;

/**
 * Exception when a client error is encountered (4xx codes)
 */
class ClientException extends \PixelCaffeine\Dependencies\GuzzleHttp\Exception\BadResponseException
{
}
