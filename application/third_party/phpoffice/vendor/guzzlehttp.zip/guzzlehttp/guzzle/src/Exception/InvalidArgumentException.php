<?php

namespace PixelCaffeine\Dependencies\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \PixelCaffeine\Dependencies\GuzzleHttp\Exception\GuzzleException
{
}
