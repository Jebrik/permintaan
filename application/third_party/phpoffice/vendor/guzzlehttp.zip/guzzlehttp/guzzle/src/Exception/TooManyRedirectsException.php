<?php

namespace PixelCaffeine\Dependencies\GuzzleHttp\Exception;

class TooManyRedirectsException extends \PixelCaffeine\Dependencies\GuzzleHttp\Exception\RequestException
{
}
