<?php

namespace PixelCaffeine\Dependencies\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \PixelCaffeine\Dependencies\GuzzleHttp\Exception\GuzzleException
{
}
