<?php

namespace PixelCaffeine\Dependencies\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \PixelCaffeine\Dependencies\GuzzleHttp\Exception\BadResponseException
{
}
