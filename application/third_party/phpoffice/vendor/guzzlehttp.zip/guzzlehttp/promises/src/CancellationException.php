<?php

namespace PixelCaffeine\Dependencies\GuzzleHttp\Promise;

/**
 * Exception that is set as the reason for a promise that has been cancelled.
 */
class CancellationException extends \PixelCaffeine\Dependencies\GuzzleHttp\Promise\RejectionException
{
}
